
package cafeteria;

public class Cliente implements Pessoa{
    private String nome;
    private String cpf;
    private String enderecoCliente;
    private String telefoneCliente;
    private int fidalidadeCliente;

    /**
     * @return the cpfCliente
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * @param cpf the cpfCliente to set
     */
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    /**
     * @return the enderecoCliente
     */
    public String getEnderecoCliente() {
        return enderecoCliente;
    }

    /**
     * @param enderecoCliente the enderecoCliente to set
     */
    public void setEnderecoCliente(String enderecoCliente) {
        this.enderecoCliente = enderecoCliente;
    }

    /**
     * @return the telefoneCliente
     */
    public String getTelefoneCliente() {
        return telefoneCliente;
    }

    /**
     * @param telefoneCliente the telefoneCliente to set
     */
    public void setTelefoneCliente(String telefoneCliente) {
        this.telefoneCliente = telefoneCliente;
    }

    /**
     * @return the fidalidadeCliente
     */
    public int getFidalidadeCliente() {
        return fidalidadeCliente;
    }

    /**
     * @param fidalidadeCliente the fidalidadeCliente to set
     */
    public void setFidalidadeCliente(int fidalidadeCliente) {
        this.fidalidadeCliente = fidalidadeCliente;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }
    
}
