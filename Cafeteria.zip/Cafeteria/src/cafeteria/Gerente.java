package cafeteria;
public class Gerente extends Funcionario{
    public double getBonificacao(){
    return this.getSalarioFuncionario()*0.10;
    }
    public void bonifica(){
        this.setSalarioFuncionario(this.getSalarioFuncionario()+this.getBonificacao());
    }
}
