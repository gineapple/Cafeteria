package cafeteria;

public interface Pessoa {
    public void setCpf(String cpf);
    public void setNome(String nome);
    public String getCpf();
    public String getNome();
    
}
