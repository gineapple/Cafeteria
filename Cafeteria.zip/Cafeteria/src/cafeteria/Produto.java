package cafeteria;

public class Produto {
    private String nomeProduto;
    private String tipoProduto;
    private int codigoProduto;
    private String dataValidade;
    private double custoProduto;
    private double precoProduto;
    
    public Produto(String nome, String tipo, int codigo){
        this.nomeProduto=nome;
        this.tipoProduto=tipo;
        this.codigoProduto=codigo;
        
    }

    public String getNomeProduto() {
        return nomeProduto;
    }

    /**
     * @param nomeProduto the nomeProduto to set
     */
    public void setNomeProduto(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }

    /**
     * @return the tipoProduto
     */
    public String getTipoProduto() {
        return tipoProduto;
    }

    /**
     * @param tipoProduto the tipoProduto to set
     */
    public void setTipoProduto(String tipoProduto) {
        this.tipoProduto = tipoProduto;
    }

    /**
     * @return the codigoProduto
     */
    public int getCodigoProduto() {
        return codigoProduto;
    }

    /**
     * @param codigoProduto the codigoProduto to set
     */
    public void setCodigoProduto(int codigoProduto) {
        this.codigoProduto = codigoProduto;
    }

    /**
     * @return the dataValidade
     */
    public String getDataValidade() {
        return dataValidade;
    }

    /**
     * @param dataValidade the dataValidade to set
     */
    public void setDataValidade(String dataValidade) {
        this.dataValidade = dataValidade;
    }

    /**
     * @return the custoProduto
     */
    public double getCustoProduto() {
        return custoProduto;
    }

    /**
     * @param custoProduto the custoProduto to set
     */
    public void setCustoProduto(double custoProduto) {
        this.custoProduto = custoProduto;
    }

    /**
     * @return the precoProduto
     */
    public double getPrecoProduto() {
        return precoProduto;
    }

    /**
     * @param precoProduto the precoProduto to set
     */
    public void setPrecoProduto(double precoProduto) {
        this.precoProduto = precoProduto;
    }
}
