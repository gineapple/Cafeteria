package cafeteria;

public class Funcionario implements Pessoa{
    private String nome;
    private String cpf;
    private String cargoFuncionario;
    private double salarioFuncionario;
    private int telefoneFuncionario;
    private String dataadmFuncionario;
    private String dataresFuncionario;

    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nomeFuncionario to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the cpfFuncionario
     */
    public String getCpf() {
        return cpf;
    }

    /**
     * @param cpf the cpfFuncionario to set
     */
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    /**
     * @return the cargoFuncionario
     */
    public String getCargoFuncionario() {
        return cargoFuncionario;
    }

    /**
     * @param cargoFuncionario the cargoFuncionario to set
     */
    public void setCargoFuncionario(String cargoFuncionario) {
        this.cargoFuncionario = cargoFuncionario;
    }

    /**
     * @return the salarioFuncionario
     */
    public double getSalarioFuncionario() {
        return salarioFuncionario;
    }

    /**
     * @param salarioFuncionario the salarioFuncionario to set
     */
    public void setSalarioFuncionario(double salarioFuncionario) {
        this.salarioFuncionario = salarioFuncionario;
    }

    /**
     * @return the telefoneFuncionario
     */
    public int getTelefoneFuncionario() {
        return telefoneFuncionario;
    }

    /**
     * @param telefoneFuncionario the telefoneFuncionario to set
     */
    public void setTelefoneFuncionario(int telefoneFuncionario) {
        this.telefoneFuncionario = telefoneFuncionario;
    }

    /**
     * @return the dataadmFuncionario
     */
    public String getDataadmFuncionario() {
        return dataadmFuncionario;
    }

    /**
     * @param dataadmFuncionario the dataadmFuncionario to set
     */
    public void setDataadmFuncionario(String dataadmFuncionario) {
        this.dataadmFuncionario = dataadmFuncionario;
    }

    /**
     * @return the dataresFuncionario
     */
    public String getDataresFuncionario() {
        return dataresFuncionario;
    }

    /**
     * @param dataresFuncionario the dataresFuncionario to set
     */
    public void setDataresFuncionario(String dataresFuncionario) {
        this.dataresFuncionario = dataresFuncionario;
    }

}
