package cafeteria;

public class Veiculo {
    private String tipoVeiculo;
    private String modeloVeiculo;
    private String placaVeiculo;
    private Funcionario motoristaVeiculo;

    /**
     * @return the tipoVeiculo
     */
    public String getTipoVeiculo() {
        return tipoVeiculo;
    }

    /**
     * @param tipoVeiculo the tipoVeiculo to set
     */
    public void setTipoVeiculo(String tipoVeiculo) {
        this.tipoVeiculo = tipoVeiculo;
    }

    /**
     * @return the modeloVeiculo
     */
    public String getModeloVeiculo() {
        return modeloVeiculo;
    }

    /**
     * @param modeloVeiculo the modeloVeiculo to set
     */
    public void setModeloVeiculo(String modeloVeiculo) {
        this.modeloVeiculo = modeloVeiculo;
    }

    /**
     * @return the placaVeiculo
     */
    public String getPlacaVeiculo() {
        return placaVeiculo;
    }

    /**
     * @param placaVeiculo the placaVeiculo to set
     */
    public void setPlacaVeiculo(String placaVeiculo) {
        this.placaVeiculo = placaVeiculo;
    }

    /**
     * @return the motoristaVeiculo
     */
    public Funcionario getMotoristaVeiculo() {
        return motoristaVeiculo;
    }

    /**
     * @param motoristaVeiculo the motoristaVeiculo to set
     */
    public void setMotoristaVeiculo(Funcionario motoristaVeiculo) {
        this.motoristaVeiculo = motoristaVeiculo;
    }
}
